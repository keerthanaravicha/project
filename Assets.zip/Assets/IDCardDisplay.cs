using UnityEngine;
using Vuforia;

public class IDCardDisplay : MonoBehaviour
{
    private ObserverBehaviour observerBehaviour;
    public GameObject idCardPanel;  // Assign in Inspector

    void Start()
    {
        observerBehaviour = GetComponent<ObserverBehaviour>();
        if (observerBehaviour)
        {
            observerBehaviour.OnTargetStatusChanged += OnTargetStatusChanged;
        }

        if (idCardPanel != null)
        {
            idCardPanel.SetActive(false);  // Ensure ID Card starts hidden
        }
        else
        {
            Debug.LogError("ID Card Panel is not assigned in Inspector!");
        }
    }

    private void OnTargetStatusChanged(ObserverBehaviour behaviour, TargetStatus status)
    {
        if (status.Status == Status.TRACKED || status.Status == Status.EXTENDED_TRACKED)
        {
            if (idCardPanel != null)
            {
                idCardPanel.SetActive(true);
            }
        }
        else
        {
            if (idCardPanel != null)
            {
                idCardPanel.SetActive(false);
            }
        }
    }
}
