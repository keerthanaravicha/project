using UnityEngine;
using Vuforia;

public class ShowSignName : MonoBehaviour
{
    public GameObject textObject;  // Assign your text object in Inspector

    void Start()
    {
        var observer = GetComponent<ObserverBehaviour>();
        if (observer)
        {
            observer.OnTargetStatusChanged += OnTargetStatusChanged;
        }

        // Hide text at start
        if (textObject) textObject.SetActive(false);
    }

    void OnTargetStatusChanged(ObserverBehaviour behaviour, TargetStatus status)
    {
        if (status.Status == Status.TRACKED || status.Status == Status.EXTENDED_TRACKED)
        {
            // Show text
            if (textObject) textObject.SetActive(true);
        }
        else
        {
            // Hide text when not tracked
            if (textObject) textObject.SetActive(false);
        }
    }
}